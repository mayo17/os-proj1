COP 4600 Operating Systems Project 1

Group Members: Jayce Houghton, Mark Yo

To compile both files, use the following command
    > make

To clean all constructed files
    > make clean

system_call
  To compile and/or run system_call
    > make runsc

  To just run system_call, this can also be used.
    > ./system_call

context_switch
  To compile and/or run context_switch
    > make runcs

  To just run context_switch, this can also be used.
    > ./context_switch
